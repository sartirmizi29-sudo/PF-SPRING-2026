#include <stdio.h>

int main() {

char chr1;

float var2;

int var3;

printf("Enter a character: ");

scanf("%c",&chr1);

printf("Enter a float: ");

scanf("%f",&var2);

printf("Enter a number: ");

scanf("%d",&var3);

printf("%c \n",chr1);

printf("%f \n", var2);

printf("%d \n", var3);

}
