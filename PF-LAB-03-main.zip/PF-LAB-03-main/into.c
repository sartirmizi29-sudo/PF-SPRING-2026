#include<stdio.h>

int main(){
  printf("This is my first c file.\n");
reurn 0;
}
