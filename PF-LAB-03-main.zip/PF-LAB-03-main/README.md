# Programming Fundamentals - LAB 03
NAME: Syed Abeer Raza Tirmizi
Roll NO: 25K-6526

# LAB Objectives
Learn Github basics
Practices C programming 
Understand branches and commits

# Completed tasks
Respositary Created
Branch created
c programs Added
