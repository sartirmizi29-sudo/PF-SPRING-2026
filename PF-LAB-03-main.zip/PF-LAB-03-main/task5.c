#include <stdio.h>

int main() {
    printf("Welcome to Programming Fundamentals\n");
    printf("Spring 2026\n");
    return 0;
}
