#include <stdio.h>

int main() {
    double var1 = 3.3;
    char chr1  = 'x';
    float var2  = 3.1456;
    int var3 = 67;

    printf("%lf \n", var1);
    printf("%lf \n", chr1);
    printf("%lf \n", var2);
    printf("%lf \n", var3);

    return 0;
}
