#include <stdio.h>

int main() {

float var1;

float var2;

float var3;

printf("Enter a float 1: ");

scanf("%f",&var1);

printf("Enter a float 2: ");

scanf("%f",&var2);

printf("Enter a float 3: ");

scanf("%f",&var3);

printf("%f \n", var1);

printf("%.21f \n", var2);

printf("%.51f \n", var3);

}
