#include <stdio.h>

int main() {
    printf("ROLL NUMBER \t NAME \t SECTION\n");
    printf("25K-6526 \t Abeer \t 2A");
    return 0;
}
